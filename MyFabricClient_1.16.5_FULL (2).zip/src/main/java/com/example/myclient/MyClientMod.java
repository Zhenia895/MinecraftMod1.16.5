
package com.example.myclient;

import net.fabricmc.api.ClientModInitializer;

public class MyClientMod implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        System.out.println("MyClientMod initialized!");
    }
}
